"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var typeorm_1 = require("typeorm");
var FilterType_1 = __importDefault(require("../entity/FilterType"));
var getSQLFilter = function (filter) {
    var relation = filter.relation, value = filter.value;
    switch (filter.relation) {
        case FilterType_1.default.between:
            return typeorm_1.Between(value, filter.value2);
        case FilterType_1.default.like:
            return typeorm_1.Like("%" + value + "%");
        case FilterType_1.default.endsWith:
            return typeorm_1.Like("%" + value);
        case FilterType_1.default.startsWith:
            return typeorm_1.Like(value + "%");
        case FilterType_1.default.equal:
            return value;
        default:
            console.error('Invalid relation found', relation);
            return;
    }
};
exports.convertFiltersToWhere = function (filters) {
    var where = {};
    if (filters.itemName) {
        where.itemName = getSQLFilter(filters.itemName);
        console.log(where.itemName);
    }
    if (filters.caseType) {
        where.caseType = getSQLFilter(filters.caseType);
    }
    if (filters.digitalType) {
        where.digitalType = getSQLFilter(filters.digitalType);
    }
    if (filters.formatType) {
        where.formatType = getSQLFilter(filters.formatType);
    }
    if (filters.is3D) {
        where.is3D = getSQLFilter(filters.is3D);
    }
    if (filters.itemStatus) {
        where.itemStatus = getSQLFilter(filters.itemStatus);
    }
    if (filters.isWatched) {
        where.isWatched = getSQLFilter(filters.isWatched);
    }
    if (filters.releaseDate) {
        where.releaseDate = getSQLFilter(filters.releaseDate);
    }
    return where;
};
//# sourceMappingURL=sql.js.map