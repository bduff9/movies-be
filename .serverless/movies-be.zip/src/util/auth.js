"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.customAuthChecker = function (_a, roles) {
    var context = _a.context;
    var _b;
    var groups = ((_b = context.claims) === null || _b === void 0 ? void 0 : _b['cognito:groups']) || [];
    var isAuthed = roles.some(function (role) {
        return groups.includes(role);
    });
    return isAuthed;
};
//# sourceMappingURL=auth.js.map