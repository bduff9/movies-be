"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var graphql_1 = require("graphql");
var DateTypeScalar = new graphql_1.GraphQLScalarType({
    name: 'DateType',
    description: 'A date without time',
    parseValue: function (value) {
        return value;
    },
    serialize: function (value) {
        return value;
    },
    parseLiteral: function (ast) {
        if (ast.kind === graphql_1.Kind.STRING) {
            return new Date(ast.value);
        }
        return null;
    },
});
exports.default = DateTypeScalar;
//# sourceMappingURL=DateType.js.map