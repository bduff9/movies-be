"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var type_graphql_1 = require("type-graphql");
var OrderType;
(function (OrderType) {
    OrderType["ASC"] = "ASC";
    OrderType["DESC"] = "DESC";
})(OrderType || (OrderType = {}));
type_graphql_1.registerEnumType(OrderType, {
    description: 'The order direction',
    name: 'OrderType',
});
exports.default = OrderType;
//# sourceMappingURL=OrderType.js.map