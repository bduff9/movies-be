"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var type_graphql_1 = require("type-graphql");
var FilterType;
(function (FilterType) {
    FilterType["between"] = "between";
    FilterType["endsWith"] = "endsWith";
    FilterType["equal"] = "equal";
    FilterType["like"] = "like";
    FilterType["startsWith"] = "startsWith";
})(FilterType || (FilterType = {}));
type_graphql_1.registerEnumType(FilterType, {
    description: 'The filter relationship',
    name: 'FilterType',
});
exports.default = FilterType;
//# sourceMappingURL=FilterType.js.map